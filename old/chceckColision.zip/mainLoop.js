function mainLoop(){
    updateInterval = setInterval(update, 1);
    //console.log("update Start");
}
