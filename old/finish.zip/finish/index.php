<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tanks v0.6</title>
    <style>
        #canvas{
            border:red 2px solid;
        
        }
        
        
        </style>
</head>
<body>
    
    <div id="score">0</div>
    <canvas id="canvas" width="300" height="300"></canvas>
    <div id="highScore"></div>
    <button type="button" id="normal" onclick=game(this)>normal mode</button>
    <button type="button" id="test" onclick=game(this)>test mode</button>
    <div id="displayArray" ><!--<pre>tekst</pre></div>-->
    <script type="text/javascript" src="onKeyDown.js"></script>
    <script type="text/javascript" src="colisionTanks.js"></script>
    <script type="text/javascript" src="randomNumber.js"></script>
    <script type="text/javascript" src="moveBots.js"></script>
    <script type="text/javascript" src="shootsBots.js"></script>
    <script type="text/javascript" src="drawTank.js"></script>
    <script type="text/javascript" src="chceckColision.js"></script>
    <script type="text/javascript" src="mainLoop.js"></script>
    <script type="text/javascript" src="game.js"></script>
    <script type="text/javascript" src="endLevel.js"></script>
    <script>
        
        const displayArray = document.querySelector("#displayArray > pre");
        const canvas = document.querySelector("#canvas");
        const scoreElement = document.querySelector("#score");
        const ctx = canvas.getContext("2d");
        var kierunek = 1;
        var skok = 30;
        var ruch = 15;
        var cords = [];
        var bricks = [];
        var water = [];
        var score = 0;
        // kierunek
        //1 s
        //2 e
        //3 n
        //4 w

        //    obiekty na mapie
        //0 droga
        //1 cegła
        //2 woda
        //3 krzaki
        //4 coś do wymyślenia
        //5 gracz
        //6 start gracza 
        //7
        const lvl1 = [
            [1,1,1,3,2,2,3,0,1,1],
            [0,0,0,2,2,3,0,0,1,1],
            [5,0,0,0,3,0,0,0,1,1],
            [3,2,0,0,0,0,0,0,0,4],
            [2,2,3,0,1,1,1,0,1,1],
            [2,3,0,0,1,1,1,0,1,1],
            [3,0,0,0,1,1,1,0,1,1],
            [0,0,0,0,0,0,0,0,0,4],
            [1,1,1,0,1,1,1,0,1,1],
            [1,1,1,0,1,1,1,4,1,1],
        ];//lvl to test
        const test = [
            [1,0,0,0,0,0,0,0,0,0],
            [0,1,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [5,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,1,0,0,0],
            [0,0,0,0,4,1,1,0,0,0],
            [0,0,0,0,1,1,1,0,0,0],
            [0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,0,1,1,0],
            [0,0,0,0,0,0,1,1,1,0],
        ];
        var count = 0;
        var startShot = 0;
        let updateInterval = null;
        let shoots = [];
        var enemies = [];
        let speed = 1;
        let rateShoot = 10;
        var gameMode = test;
        var dlugoscX = gameMode.length * skok;
        var dlugoscY = gameMode.length * skok;
        var bots = [];
        var rate = 0;
        let gameName = 'tanks';
        start();
        mainLoop();


        function start(){
            
            ctx.fillStyle = "grey";
            ctx.fillRect(0,0,canvas.width,canvas.height);
            bricks =[];
            water = [];
            kierunek = 2;
            for(var j =0;j < gameMode.length; j++){
                for(var i =0;i < gameMode[j].length; i++){
                    if(gameMode[j][i] === 1){
                        ctx.fillStyle = "red";
                        ctx.fillRect(i*skok,j*skok,skok,skok);
                        bricks.push([i*skok,j*skok]);
                    }else if(gameMode[j][i] === 2){
                        ctx.fillStyle = "blue";
                        ctx.fillRect(i*skok,j*skok,skok,skok);
                        water.push([i*skok,j*skok]);
                    }else if(gameMode[j][i] === 3){
                        ctx.fillStyle = "green";
                        ctx.fillRect(i*skok,j*skok,skok,skok);
                    }else if(gameMode[j][i] === 4){
                        //ctx.fillStyle = "brown";
                        bots.push([i*skok,j*skok,1,false]);
                        drawTank(i*skok,j*skok,1,false)
                        //ctx.fillRect(i*skok,j*skok,skok,skok);
                    }else if(gameMode[j][i] === 0){
                        ctx.fillStyle = "grey";
                        ctx.fillRect(i*skok,j*skok,skok,skok);
                    }else if(gameMode[j][i] === 5){
                        cords.push(i*skok,j*skok,2,true);
                        drawTank(cords[0],cords[1],cords[2],cords[3])
                        // ctx.fillStyle = "grey";
                        // ctx.fillRect(cords[0],cords[1],skok,skok); //tło
                        // ctx.fillStyle = "#494646";
                        // ctx.fillRect(cords[0],cords[1],skok,5); //gąska1
                        // ctx.fillRect(cords[0],cords[1]+25,skok,5); //gąska2
                        // ctx.fillStyle = "#6b6969";
                        // ctx.fillRect(cords[0]+3,cords[1]+5,22,20); //kadłub
                        // ctx.fillStyle = "#d2ced1";
                        // ctx.fillRect(cords[0]+15,cords[1]+13,15,3); //działo
                        // ctx.fillStyle = "#494646";
                        ctx.fillRect(cords[0]+9,cords[1]+9,12,12); //wieża
                        gameMode[j][i] = 6;
                    }
                }
            }
            //console.log('Mode build',bricks.length);
        }

        function update(){
            ctx.clearRect(0, 0, canvas.width, canvas.height); // czyszczenie            
            ctx.fillStyle = "grey";
            ctx.fillRect(0,0,canvas.width,canvas.height);
            //ruszanie botów
            
            //console.log(rate)
            //ograniczenie strzałów
            if(rateShoot <= 100){
               rateShoot++;  
            }
            //rysowanie czołgów
            for(var i = 0; i <bots.length;i++){
            drawTank(bots[i][0],bots[i][1],bots[i][2],bots[3])               
            }

            for(var j =0;j < gameMode.length; j++){
                for(var i =0;i < gameMode[j].length; i++){
                    if(gameMode[j][i] === 2){
                          ctx.fillStyle = "blue";
                         ctx.fillRect(i*skok,j*skok,skok,skok);
                    } else if(gameMode[j][i] === 3){
                          ctx.fillStyle = "green";
                         ctx.fillRect(i*skok,j*skok,skok,skok);
                    // } 
                    // else if(gameMode[j][i] === 4){
                    //       ctx.fillStyle = "brown";
                    //      ctx.fillRect(i*skok,j*skok,skok,skok);
                    } else if(gameMode[j][i] === 6){
                          ctx.fillStyle = "grey";
                         ctx.fillRect(i*skok,j*skok,skok,skok);
                    }
                }
            }
            if(rate <= 200){
                            rate++;
                        }else{
                            rate = 0;
                            for(var i = 0;i < bots.length; i++){
                                //console.log("-------",moveBots(bots[i][0],bots[i][1],bots[2],i))
                                //moveBots(bots[i][0],bots[i][1],bots[2],i)
                            
                                let botPos = moveBots(bots[i][0],bots[i][1],bots[i][2],i);
                                //console.log(botPos)
                                if(botPos){

                                    
                                    bots[i] = []
                                    bots[i] = botPos;
                                    //console.log(bots)
                                }
                            }
                        }
            for(var i = 0; i < bricks.length;i++){
                ctx.fillStyle = "red";
                ctx.fillRect(bricks[i][0],bricks[i][1],skok,skok);
            }
            //console.log("długość tabeli:",bricks.length,"zawartość tabeli:",bricks )                         
            drawTank(cords[0],cords[1],cords[2],cords[3])
            for(let i= 0;i < shoots.length;i++ ){
                ctx.fillStyle = "orange";
                switch(shoots[i].dir){
                    case 1:
                        shoots[i].y += speed;
                        ctx.fillRect(shoots[i].x,shoots[i].y+20,3,5);
                    break;
                    case 2:
                        shoots[i].x += speed;
                        ctx.fillRect(shoots[i].x+7,shoots[i].y+13,5,3);
                    break;
                    case 3:
                        shoots[i].y -= speed;
                        ctx.fillRect(shoots[i].x,shoots[i].y+5,3,5);
                    break;
                    case 4:
                        shoots[i].x -= speed;
                        ctx.fillRect(shoots[i].x-7,shoots[i].y+13,5,3);
                    break;
                }
               
                if(checkColision(shoots[i]) === true){
                    shoots.splice(i,1);
                }
                if(checkColision(shoots[i]) === true){
                    bots.splice(i);
                }
            } 
            // console.log(bricks);
            //console.log(cords )
        }
        function fetchScore(){
            let xhr = new XMLHttpRequest();
            
            xhr.open('GET', 'connection.php', true);

            xhr.onload = function(){
                console.log(this.responseText);

                scoreData = JSON.parse(this.responseText);

                var output = '<ol>';

                for (var i in scoreData){
                    output += '<li><span class="name">' + scoreData[i].name + '</span><span>score: ' + scoreData[i].score + ' clicks</span></li>';
                }

                output += '</ol>';

                document.querySelector('#highScore').innerHTML = output;
            }

            xhr.send();
        }
        function endLevel(){
    clearInterval(updateInterval); //wywołąnie ekranu końcowego
    var person = prompt('Your score is ' + score + '!!! ' + 'Enter your name:');

            if(person !== null){
            //sendScore(game,person,score);
            console.log("wyślij", person,gameName,score)
            console.log(sendScore(gameName,person,score))
            sendScore(gameName,person,score)
            }
            
    

}
        function sendScore(game,person,score){
            let xhr = new XMLHttpRequest();

            let params = "game=" + gameName + "&name=" + person + "&score=" + score;

            xhr.open('POST', 'addScore.php', true);
            xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');

            xhr.onload = function(){
                fetchScore();
            }

            xhr.send(params);
        }
    </script>
     <br>
     <br><b>#TODO</b><br>
     -podłączyć strzały<br>
     <br><b>change log:</b><br>
    v0.6<br>
        -dodanie botów<br>
    v0.5 <br>
        -zmiana rysowania cegieł<br>
        -niszczenie cegieł po trafieniu <br>
    v0.4<br>
        -strzelanie<br>
        -kolizja pocisku z granicą mapy<br>
        -kolizja pocisku z cegłami <br>
    v0.3<br>
        -zablokowanie poruszania przez cegły i wode<br>
    v0.2 <br>
        -model pojazdu <br>
        -obracanie modelu względem ruchu <br>
    v0.1 <br>
        -mapa<br> 
        -poruszanie sie<br>
        -zablokowane granice<br> 
</body>
</html>