function randomNumber(number){
    var number = (Math.floor(Math.random() * 3)+1);

    return number
}
